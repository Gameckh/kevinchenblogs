module.exports = {
    devServer: {
        port: 3000,
        proxy: {
          //匹配到的路径
          "/api": {
            target: "http://localhost:8089", //目标主机地址
            changeOrigin: true, //是否启动代理
            pathRewrite: {
              "^/api": "" //如果遇到前缀为'/api'的url，将它重写为''
            }
          }
        }
    },
    pwa: {
        iconPaths: {
            favicon32: 'public/logo.png',
            favicon16: 'public/logo.png'
        }
    }
  }