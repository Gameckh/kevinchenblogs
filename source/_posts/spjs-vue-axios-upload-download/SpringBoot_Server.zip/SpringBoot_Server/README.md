# SpreadJS+GcExcel复杂文档加载方案
Demo结合SpreadJS和GcExcel，用以解决加载包含复杂计算逻辑的Excel文档。\
Demo中附带了一个46M的Excel文档，包含近6W个计算公式、247个sheet表格。实测在本地用Office Excel直接打开，需耗时近20秒。\

### 使用方法
  #### 环境依赖：
  * 需安装JDK8.0及以上版本，或OpenJRE等Java依赖的运行环境，并配置好环境变量
  * Eclipse 或其它合适的IDE工具。

  #### 项目启动：
* Demo是基于Java maven的Web应用，可以直接导入Eclipse，等待远程库加载完成后，运行GcExcelAndSpreadJsApplication类即可。
* 运行成功后，可以在本地浏览器中输入：localhost:8089，即可进入Demo页面。完整的Demo页面包含一个按钮，和一个已初始化完成的SpreadJS表格区域

  #### 执行导入：
* 点击页面按钮后，会出现Loading效果，等待加载后台的Excel文档。加载完成后，即可执行双击编辑的操作。

### 说明
  本Demo仅演示了编辑单个单元格的前后端联动效果，如需支持其它前后端联动功能，可按照Demo思路进一步开发实现。