package GrapeCity.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

@RestController
@RequestMapping({ "Spread", "spread" })
public class SpreadController {
	public static final String xlsxFile = "GcExcel资料索引.xlsx";

	public SpreadController() {

	}

	// 接收前台上传的blob文档，保存到server端
	@RequestMapping(value = "/saveExport", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> saveExport(HttpServletRequest request) throws IOException, ServletException {
		int result = 0;
		Map<String, Object> resultMap = new HashMap<String, Object>();
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		Map<String, MultipartFile> fileMap = multipartRequest.getFileMap();
		MultipartFile file = fileMap.get("test.xlsx");
		// 测试将上传文件转存至指定路径，模拟服务器保存
		File newfile = new File(SpreadController.class.getResource("/").getPath() + "files/test.xlsx");
		System.out.println("保存位置：" + newfile.getAbsolutePath());
		try {
			file.transferTo(newfile);
			resultMap.put("isSuccess", 1);
			resultMap.put("localPath", newfile.getAbsolutePath());
		} catch (Exception e) {
			resultMap.put("isSuccess", result);
			resultMap.put("errorMessage", e.getMessage());
			e.printStackTrace();
		}
		return resultMap;
	}

	@RequestMapping(value = "/importXlsx", method = RequestMethod.POST)
	@ResponseBody
	public void importXlsx(HttpServletRequest request, HttpServletResponse response, Model model) {
		int size = 4096;
		OutputStream os = null;
		String ssjsonPath = SpreadController.class.getResource("/").getPath() + "files/" + xlsxFile;
		File importFile = new File(ssjsonPath);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(importFile);
			int len = 0;
			byte[] buf = new byte[size];
			os = response.getOutputStream();
			while ((len = fis.read(buf)) != -1) {
				os.write(buf, 0, len);
				os.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@RequestMapping(value = "/test", method = RequestMethod.POST)
	public Map<String, Object> test(HttpServletRequest request, HttpServletResponse response, Model model) {
		System.out.println("++++++++++++++++++++++++++++++++++++++++++++++");
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("isSuccess", 1);
		return resultMap;
	}

}