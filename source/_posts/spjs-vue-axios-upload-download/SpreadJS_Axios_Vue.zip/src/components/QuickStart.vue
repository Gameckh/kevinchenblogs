<template>
  <div class="componentContainer">
    <h3>SpreadJS + Vue + axios 实现服务期端上传下载Excel文档</h3>
    <div>
      Steps for getting started with the SpreadJS in Vue applications:
      <div>
        <p>
          <button id="importXlsx" @click="importXlsx($event)">导入Xlsx</button>
        </p>
        <p>
          <button id="exportXlsx" @click="exportXlsx($event)">上传Xlsx</button>
        </p>
        <p>
          <button id="test" @click="test($event)">Test</button>
        </p>
      </div>
    </div>
    <div class="spreadContainer">
      <gc-spread-sheets
        :hostClass="'spreadHost'"
        @workbookInitialized="spreadInitHandle($event)"
      >
      </gc-spread-sheets>
    </div>
  </div>
</template>
<script>
import "@grapecity/spread-sheets-vue";
import GC from "@grapecity/spread-sheets";
import { IO } from "@grapecity/spread-excelio";
import axios from "axios";

export default {
  data() {
    return {
      spread: {}
    };
  },
  methods: {
    test: function() {
      
      axios({
        method: "post",
        url: "spread/test"
      }).then(
        response => {
          console.log(response);
        },
        err => {
          console.log(err);
        }
      );
    },
    importXlsx: function() {
      const excelIo = new IO();
      axios({
        method: "post",
        url: "spread/importXlsx",
        responseType: "blob",
        headers: {
          cache: false,
          "Content-Type": "application/x-www-form-urlencoded",
          processData: false,
          "Access-Control-Allow-Origin": "*",
          'X-Requested-With': 'XMLHttpRequest',
          crossDomain: true
        }
      }).then(
        response => {
          // 加载Excel
          console.log(response);
          excelIo.open(response.data, json => {
            this.spread.fromJSON(json);
          });
        },
        err => {
          console.log(err);
        }
      );
    },
    exportXlsx: function() {
      const json = this.spread.toJSON();
      const excelIo = new IO();
      excelIo.save(json, blob => {
        const fd = new FormData();
        fd.append("test.xlsx", blob);
        axios({
          method: "post",
          url: "spread/saveExport",
          data: fd,
          headers: {
            cache: false,
            "Content-Type": "application/x-www-form-urlencoded",
            processData: false,
            "Access-Control-Allow-Origin": "*",
            crossDomain: true
          },
          withCredentials: true
        }).then(
          response => {
            if (response.data.isSuccess == 1) {
              alert("上传成功！保存位置：" + response.data.localPath);
            }
          },
          err => {
            alert(err.errorMessage);
          }
        );
      });
    },
    spreadInitHandle: function(spread) {
      this.spread = spread;
      axios.defaults.timeout = 10000;
      // 默认所有请求都走本地代理
      axios.defaults.baseURL = "/api";
    }
  }
};
</script>
<style scoped>
.componentContainer {
  position: absolute;
  padding: 10px;
  left: 242px;
  top: 0;
  bottom: 20px;
  right: 0;
}
.spreadContainer {
  padding: 10px;
  box-shadow: 0 0 20px grey;
}
.spreadContainer {
  position: absolute;
  left: 0px;
  right: 30px;
  top: 260px;
  bottom: 10px;
}
.spreadHost {
  width: 100%;
  height: 100%;
}
</style>
