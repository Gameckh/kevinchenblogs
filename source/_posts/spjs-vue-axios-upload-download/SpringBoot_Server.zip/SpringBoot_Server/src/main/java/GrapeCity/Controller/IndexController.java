package GrapeCity.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

//@RestController
//@RequestMapping({"/", "Home"})
//public class IndexController {
//	
//	@RequestMapping({"", "Index"})
//	public String Index(){
//		
//		return "Hello World";
//	}
//}

@Controller
@RequestMapping({"/", "Home"})
public class IndexController {

    /**
     * Controller function for the index HTML page.
     */
    @RequestMapping("/")
    public String index(Model model) {
        return "index";
    }
    
    @RequestMapping(value="/hello",method= RequestMethod.GET)
    public String sayHello(){
        return "hello";
    }
  
}
