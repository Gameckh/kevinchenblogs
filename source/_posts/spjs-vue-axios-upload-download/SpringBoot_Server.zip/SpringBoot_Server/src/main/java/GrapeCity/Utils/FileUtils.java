package GrapeCity.Utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class FileUtils {
  public static void writeToFile(String content, String filePath) {
    try {
      File file = new File(filePath);
      // if file doesnt exists, then create it
      if (!file.exists()) {
        file.createNewFile();
        // true = append file
        FileWriter fileWritter = new FileWriter(file);
        BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
        bufferWritter.write(content);
        bufferWritter.close();
      }
      System.out.println("Writ to ssjson Done");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static String readFromFile(String filePath) {
    StringBuilder content = new StringBuilder();
    BufferedReader in = null;
    try {
      in = new BufferedReader(new FileReader(filePath));
      String line;
      while ((line = in.readLine()) != null) {
        content.append(line);
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        if(in != null){
          in.close();
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return content.toString();
  }

  public static void main(String[] args) {
    System.out.println(FileUtils.class.getResource("/").getPath());
    writeToFile("test11111.ssjson", FileUtils.class.getResource("/").getPath() + "files/test.ssjson");
  }
}